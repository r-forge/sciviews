guiUninstall <- function ()
{
	## Eliminate .guiCmd
	rmTemp(".guiCmd")
	rmTemp(".guiObjBrowse")
	rmTemp(".guiObjInfo")
	rmTemp(".guiObjMenu")

	rmTemp(".koCmd")

	## Unregister our own TaskCallback
	h <- getTemp(".svTaskCallbackManager", default = NULL, mode = "list")
	if (!is.null(h))
		h$remove("guiAutoRefresh")
}
