isWin <- function ()
	(.Platform$OS.type == "windows")
