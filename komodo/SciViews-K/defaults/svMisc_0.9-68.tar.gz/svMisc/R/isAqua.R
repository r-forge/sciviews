isAqua <- function ()
	(.Platform$GUI[1] == "AQUA")