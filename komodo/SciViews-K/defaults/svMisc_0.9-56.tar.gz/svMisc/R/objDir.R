"objDir" <-
function ()
    file.path(tempdir(), "svObjBrowser")
