.First.lib=function(lib,pkg)library.dynam("data.table",pkg,lib)

