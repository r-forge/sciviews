"objList" <-
function (id = "default", envir = .GlobalEnv, object = NULL, all.names = FALSE,
pattern = "", group = "", all.info = FALSE, sep = "\t", path = NULL, compare = TRUE, ...)
{
	# Make sure that id is character
	id <- as.character(id)[1]
	if (id == "") id <- "default"

	# Format envir as character (use only first item provided!)
	if (!is.environment(envir)){
		envir <- tryCatch(as.environment(envir), error = function(e) NULL)
		if (is.null(envir) || inherits(envir, "try-error")) {
			envir <- NULL
			ename <- ""
		} else {
			ename <- if (is.null(attr(envir, "name"))) ".GlobalEnv" else attr(envir, "name")
		}
	} else {
		ename <- deparse(substitute(envir))
	}

	# Object to return in case of empty data
	Nothing <- data.frame(Envir = character(0), Name = character(0),
		Dims = character(0), Group = character(0), Class = character(0),
		Recursive = logical(0), stringsAsFactors = FALSE)
	if (!all.info) Nothing <- Nothing[, -1]
	attr(Nothing, "all.info") <- all.info
	attr(Nothing, "envir") <- ename
	attr(Nothing, "object") <- object
	attr(Nothing, "class") <- c("objList", "data.frame")

	if (is.null(envir))
		return(Nothing)

	if (!missing(object) && is.character(object) && object != "") {
		res <- lsObj(envir = envir, objname = object)
	} else {
		# Get the list of objects in this environment
		Items <- ls(envir = envir, all.names = all.names, pattern = pattern)
		if (length(Items) == 0) {
			return(Nothing)
		}

		# Get characteristics of all objects
		"describe" <- function (name, all.info = FALSE)
		{
			# get a vector with five items:
			# Name, Dims, Group, Class and Recursive
			obj <- envir[[name]]
			res <- c(
				Name = name,
				Dims = if (is.null(Dim <- dim(obj))) length(obj) else
					paste(Dim, collapse = "x"),
				Group = mode(obj),
				Class = class(obj)[1],
				Recursive = is.recursive(obj) || mode(obj) == "S4"
			)
			return(res)
		}
		res <- data.frame(t(sapply(Items, describe, all.info = all.info)),
			stringsAsFactors = FALSE)
	}

	if (NROW(res) == 0)
		return(Nothing)

	if (isTRUE(all.info))
		res <- cbind(Envir = ename, res)

	vMode <- Groups <- res$Group
	vClass <- res$Class

	# Recalculate groups into meaningful ones for the object explorer
	# 1) Correspondance of typeof() and group depicted in the browser
	#{{
	Groups[Groups %in% c("name", "environment", "promise", "language", "char",
		"...", "any", "(", "call", "expression", "bytecode", "weakref",
		"externalptr")] <- "language"

	Groups[Groups == "pairlist"] <- "list"

	# 2) All Groups not being language, function or S4 whose class is
	#    different than typeof are flagged as S3 objects
	Groups[!(Groups %in% c("language", "function", "S4")) & vMode != vClass] <- "S3"

	# 3) Integers of class factor become factor in group
	Groups[vClass == "factor"] <- "factor"

	# 4) Objects of class 'data.frame' are also group 'data.frame'
	Groups[vClass == "data.frame"] <- "data.frame"

	# 5) Objects of class 'Date' or 'POSIXt' are of group 'DateTime'
	Groups[vClass == "Date" | vClass == "POSIXt"] <- "DateTime"

	# Reaffect groups
	res$Group <- Groups

	# Possibly filter according to group
	if (!is.null(group) && group != "")
		res <- res[Groups == group, ]
	#}}

	# Determine if it is required to refresh something
	Changed <- TRUE
	if (compare) {
		allList <- getTemp(".guiObjListCache", default = list())

		if (identical(res, allList[[id]])) Changed <- FALSE else {
			# Keep a copy of the last version in TempEnv
			allList[[id]] <- res
			assignTemp(".guiObjListCache", allList)
		}
	}
	
	# Create the 'objList' object
	attr(res, "all.info") <- all.info
	attr(res, "envir") <- ename
	attr(res, "object") <- object
	attr(res, "class") <- c("objList", "data.frame")

	if (is.null(path)) { # Return results or "" if not changed
		return(if (Changed) res else Nothing)
	} else if (Changed) { # Write to files in this path
		return(write.objList(res, path = path, sep = sep, ...))
	} else {
		return(Nothing) # Not changed
	}
}

"write.objList" <-
function (x, path, sep = "\t", ...)
{
	id <- attr(x, "id")
	ListF <- file.path(path, sprintf("List_%s.txt", id))
	ParsF <- file.path(path, sprintf("Pars_%s.txt", id))

	write.table(as.data.frame(x), row.names = FALSE, col.names = FALSE,
		sep = sep, quote = FALSE, file = ListF)

	# Write also in the Pars_<id>.txt file in the same directory
	cat(sprintf("envir=%s\nall.names=%s\npattern=%s\ngroup=%s",
		attr(x, "envir"), attr(x, "all.names"), attr(x, "pattern"),
		attr(x, "group")), file = ParsF, append = FALSE)

	return(invisible(ListF))
}

"print.objList" <-
function (x, sep = NA, eol = "\n", header = !attr(x, "all.info"), ...)
{
	if (!inherits(x, "objList"))
		stop("x must be an 'objList' object")
	if (NROW(x) > 0) {
		cat("Objects list:\n")
		if (header) {
			cat("\tEnvironment = ", attr(x, "envir"), "\n", sep = "")
			cat("\tObject = ", if (is.null(attr(x, "object"))) "" else
				attr(x, "object"), "\n", sep = "")
		}

		if (is.na(sep)) {
			cat("\n")
			print(as.data.frame(x))
		} else if (!is.null(nrow(x)) && nrow(x) > 0) {
			write.table(x, row.names = FALSE, col.names = FALSE, sep = sep,
				eol = eol, quote = FALSE)
		}
	} else {
		cat("An empty objects list\n")
	}
	return(invisible(x))
}

# called by objList when object is provided
# TODO: simplify, possibly merge lsObj.S4 into lsObj
"lsObj" <-
function (objname, envir, ...)
{
	obj <- try(eval(parse(text = objname)), silent = TRUE)
	if (inherits(obj, "try-error"))
		return(NULL)

	if (mode(obj) == "S4") {
		ret <- lsObj.S4(obj, objname)
	} else if (is.function(obj)) {
		ret <- lsObj.function(obj, objname)
	} else {	# S3
#{{
		if (!(mode(obj) %in% c("list", "pairlist")) || length(obj) == 0)
			return(NULL)

		itemnames <- fullnames <- names(obj)
		if (is.null(itemnames)) {
			itemnames <- seq_along(obj)
			fullnames <- paste(objname, "[[", seq_along(obj), "]]", sep = "")
		} else {
			w.names <- itemnames != ""
			.names <- itemnames[w.names]
			nsx <- .names != make.names(.names) # non-syntactic names
			.names[nsx] <- paste("`", .names[nsx], "`", sep = "")
			fullnames[w.names] <- paste (objname, "$", .names, sep = "")
			fullnames[!w.names] <- paste(objname, "[[",
				seq_along(itemnames)[!w.names], "]]", sep = "")
		}

		ret <- t(sapply(seq_along(obj), function (i) {
			x <- obj[[i]]

			d <- dim(x)
			if (is.null(d)) d <- length(x)

			ret <- c(paste(d, collapse = "x"), mode(x), class(x)[1],
				is.function(x) || (is.recursive(x) && !is.language(x) && sum(d) != 0)
			)
			return(ret)
		}))

		ret <- data.frame(itemnames, fullnames, ret, stringsAsFactors = FALSE)
#}}
	}
	if (!is.null(ret))
		names(ret) <- c("Name", "Full.name", "Dims/default", "Group", "Class",
			"Recursive")
	return (ret)
}

# called by lsObj
"lsObj.function" <-
function (obj, objname = deparse(substitute(obj)))
{
	#  formals(obj) returns NULL if only arg is ..., try: formals(expression)
	obj <- formals(args(obj))
	objname <- paste("formals(args(", objname, "))", sep = "")

	if(length(obj) == 0)
		return(NULL)

	itemnames <- fullnames <- names(obj)
	nsx <- itemnames != make.names(itemnames) # non-syntactic names
	itemnames[nsx] <- paste("`", itemnames[nsx], "`", sep = "")
	fullnames <- paste(objname, "$", itemnames, sep = "")

	ret <- t(sapply (seq_along(obj), function (i) {
		x <- obj[[i]]
		lang <- is.language(obj[[i]])
		o.class <- class(obj[[i]])[1]
		o.mode <- mode(obj[[i]])

		d <- deparse(obj[[i]])
		if (lang && o.class == "name") {
			o.class <- ""
			o.mode <- ""
		}

		ret <- c(paste(d, collapse = "x"), o.class,	o.mode, FALSE)
		return(ret)
	}))

	ret <- data.frame(itemnames, fullnames, ret, stringsAsFactors = FALSE)
	return (ret)
}


# called by lsObj in S4 case
"lsObj.S4" <-
function (obj, objname = deparse(substitute(obj)))
{
	itemnames <- fullnames <- slotNames(obj)
	nsx <- itemnames != make.names(itemnames)
	itemnames[nsx] <- paste("`", itemnames[nsx], "`", sep = "")
	fullnames <- paste(objname, "@", itemnames, sep = "")

	ret <- t(sapply(itemnames, function (i) {
		x <- slot(obj, i)

		d <- dim(x)
		if (is.null(d)) d <- length(x)

		ret <- c(paste(d, collapse = "x"), mode(x), class(x)[1],
			is.function(x) || (is.recursive(x) && !is.language(x) && sum(d) != 0))
	}))

	ret <- data.frame(itemnames, fullnames, ret, stringsAsFactors = FALSE)
	return(ret)
}
