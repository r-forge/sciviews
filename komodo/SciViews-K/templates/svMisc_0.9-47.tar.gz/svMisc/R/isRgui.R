"isRgui" <-
function() (.Platform$GUI[1] == "Rgui")
