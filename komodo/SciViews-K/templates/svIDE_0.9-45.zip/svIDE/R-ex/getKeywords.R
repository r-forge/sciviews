### Name: getKeywords
### Title: get all keywords for syntax highlighting
### Aliases: getKeywords
### Keywords: utilities

### ** Examples

        getKeywords(1:2)



