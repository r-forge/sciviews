### Name: sendSocketServer
### Title: Send data to an existing R socket server and disconnect.
### Aliases: sendSocketServer
### Keywords: IO

### ** Examples

## Not run: 
##D # Start a R socket server in an instance #1 of R
##D # require(svSocket)
##D # startSocketServer()
##D # data(iris) # To get something in .GlobalEnv
##D #
##D # Now, start an instance #2 of R on the same machine and do:
##D require(svSocket)
##D cat(sendSocketServer("ls()"))
##D # You should read, at least, iris
##D cat(sendSocketServer("x <- 2"))
##D # Nothing happens, but switch to R #1 and type
##D # x
##D # to see the result
## End(Not run)



