"isMac" <-
function ()
	(.Platform$pkgType == "mac.binary")
