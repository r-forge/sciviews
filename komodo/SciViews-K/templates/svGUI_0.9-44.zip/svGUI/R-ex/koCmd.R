### Name: koCmd
### Title: Connect to the SciViews-K (Komodo Edit) socket server and run
###   javascript code in Komodo
### Aliases: koCmd
### Keywords: IO

### ** Examples

## Not run: 
##D # Make sure you have started Komodo Edit with the SciViews-K extension installed
##D # on the same machine you run R, and the socket server started and then...
##D 
##D # Alert box in Komodo, and then reply to R
##D koCmd(c('alert("Hello from R!");',
##D     'sv.socket.serverWrite("Hello from OpenKomodo (" + ko.interpolate.currentFilePath() + ")");'))
##D 
##D # Open a web page wih Komodo configuration
##D koCmd("ko.open.URI('about:config','browser');")
##D 
##D # Get info from Komodo
##D koCmd("sv.socket.serverWrite(ko.logging.getStack());")
##D 
##D # Passing a large amount of data to Komodo, and then, back to R
##D koCmd(paste('sv.socket.serverWrite("', rep(paste(iris, collapse = "\\n"), 10), '");', sep = ""))
##D 
##D # It is easier to use 'data =' instead of paste() for constructing the JS command
##D koCmd('alert("<<<data>>>");', data = search())
##D 
##D # Using a named list for data to replace in the cmd
##D koCmd('alert("This is R version <<<major>>>.<<<minor>>>");', R.version)
##D 
##D # Sending incorrect javascript instruction
##D res <- koCmd('nonexistingJSfunction();')
##D res
##D if (inherits(res, "try-error")) cat("Error detected!")
## End(Not run)



